# AWS Lambda Backend (TypeScript)

This folder will contain TypeScript AWS Lambda handlers for API Gateway.
See ADR-002 for decision rationale.